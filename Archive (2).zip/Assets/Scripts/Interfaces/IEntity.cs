namespace Interfaces
{
    public interface IEntity
    {
        public void Fall();
    }
}
