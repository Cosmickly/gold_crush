using Players;

namespace Interfaces
{
    public interface ICollectable
    {
        public void Collect(BasePlayer player);
    }
}
