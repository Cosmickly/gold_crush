namespace Interfaces
{
    public interface IHittable
    {
        public void Hit();
    }
}